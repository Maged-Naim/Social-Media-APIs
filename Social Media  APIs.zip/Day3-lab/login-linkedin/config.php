<?php



define("CLIENT_ID", "86f3aynh9cr44x");
define("CLIENT_SECRET", "CwzYVyaSLhbqUGzU");
define('REDIRECT_URL', 'http://localhost:8000/callback.php');


?>