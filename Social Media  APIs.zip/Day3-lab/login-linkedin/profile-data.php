<?php
session_start();

require __DIR__ . '/vendor/autoload.php';
require __DIR__ . '/config.php';

$token = $_SESSION['access_token'];
$url = "https://api.linkedin.com/v2/me";

$client = new \GuzzleHttp\Client();
$user_profile_response = $client->get($url, [
    "query" => ["oauth2_access_token" => $token]
    ]); 
 header('Content-Type:application/json');
$body = $user_profile_response->getBody();
$profile = json_decode($body);
print_r($profile);