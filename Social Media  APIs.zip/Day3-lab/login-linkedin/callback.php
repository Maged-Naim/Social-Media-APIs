<?php
session_start();

require __DIR__ . '/vendor/autoload.php';
require __DIR__ . '/config.php';

if(isset( $_GET['code'])){

$code = $_GET['code'];
$client = new \GuzzleHttp\Client();
$response = $client->post('https://www.linkedin.com/oauth/v2/accessToken',
[
    'form_params'=>[
        "grant_type"=>"authorization_code",
        'code'=>$code,
        "redirect_uri" => REDIRECT_URL,
        "client_id" => CLIENT_ID,
        "client_secret" => CLIENT_SECRET

       

    ]
]);
       
        $body = $response->getBody();
        $access_token = json_decode($body);
        $_SESSION['access_token'] = $access_token->access_token;
        header('location: /profile-data.php');
        
  }else{
      header('location : /login.php');
    
  }